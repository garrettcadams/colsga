<?php
/* Move to 'mypage/home/index.php' */