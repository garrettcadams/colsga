<div class="javo-map-inner-control-wrap">
	<div class="jvbpd-map-control control-zoom-in"><i class="fa fa-minus"></i></div>
	<div class="jvbpd-map-control control-zoom-out"><i class="fa fa-plus"></i></div>
	<div class="jvbpd-map-control" data-map-move-allow title="<?php esc_html_e('Lock' , 'javospot') ?>" data-unlock="<?php esc_html_e('UnLock' , 'javospot') ?>" data-lock="<?php esc_html_e('Lock','javospot'); ?>">
		<i class="fa fa-unlock"></i>
	</div>
</div><!-- /.javo-map-inner-control-wrap -->