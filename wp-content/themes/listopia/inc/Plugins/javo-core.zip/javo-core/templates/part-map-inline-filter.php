<div id="javo-maps-listings-switcher">
	<input type="radio" name="m" value="<?php echo function_exists( 'jvbpd_elements_tools' ) ? jvbpd_elements_tools()->getMapType() : 'maps'; ?>" checked="checked" class="hidden">
</div>