<div id="javo-maps-wrap" class="hidden">
	<?php
	//get_template_part( 'includes/templates/part-map-type', 'map' );
	jvbpdCore()->template_instance->load_template( 'part-map-type-map' ); ?>
</div>
<div id="javo-listings-wrap" class="hidden">
	<?php
	// get_template_part( 'includes/templates/part-map-type', 'list' );
	jvbpdCore()->template_instance->load_template( 'part-map-type-list' );?>
</div>