<div class="jvbpd-map-distance-bar-wrap open">
	<div class="text-right">
		<button type="button" data-close="">
			<i class="fa fa-remove"></i>
		</button>
	</div>
	<div class="javo-geoloc-slider"></div>
</div>