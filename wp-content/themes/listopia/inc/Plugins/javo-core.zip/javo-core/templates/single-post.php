<?php
get_header();
Jvbpd_Listing_Elementor::get_custom_single_post_content();
get_footer();