<div class="card control-panel-in-map">
	<div class="total-count"><span class="count" data-suffix="">40</span> <?php esc_html_e( "Listing(s)", 'jvfrmtd' ); ?></div>
	<div class="btn-group">
		<button type="button" class="btn btn-sm reset-filter"><?php esc_html_e( "Reset", 'jvfrmtd' ); ?></button>
		<button type="button" class="btn btn-sm current-search"><?php esc_html_e( "Locate Search", 'jvfrmtd' ); ?></button>
	</div>
</div>