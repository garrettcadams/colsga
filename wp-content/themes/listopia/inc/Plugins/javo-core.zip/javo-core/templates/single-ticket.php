<?php
get_header();
Jvbpd_Listing_Elementor::get_custom_single_ticket_content();
get_footer();