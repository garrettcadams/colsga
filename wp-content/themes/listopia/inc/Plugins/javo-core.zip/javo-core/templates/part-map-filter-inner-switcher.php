<div class="javo-map-box-inner-switcher inline-block">
	<button type="button" class="btn btn-primary admin-color-setting" data-value="map">
		<span data-value="map">
			<i class="fa fa-bars"></i>
			<?php _e( "List", 'jvfrmtd' ); ?>
		</span>
		<span class="hidden" data-value="list">
			<i class="fa fa-globe"></i>
			<?php _e( "Map", 'jvfrmtd' ); ?>
		</span>
	</button>
</div>