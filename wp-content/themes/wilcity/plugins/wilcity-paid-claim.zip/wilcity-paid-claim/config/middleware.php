<?php
return [
	'isClaimAvailable' => 'WilcityPaidClaim\Middleware\IsClaimAvailable',
];