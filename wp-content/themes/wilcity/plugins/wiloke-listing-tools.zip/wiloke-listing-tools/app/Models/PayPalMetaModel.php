<?php

namespace WilokeListingTools\Models;


class PayPalMetaModel {

}