<?php

namespace WilokeListingTools\Models;


class FollowerModel {

}