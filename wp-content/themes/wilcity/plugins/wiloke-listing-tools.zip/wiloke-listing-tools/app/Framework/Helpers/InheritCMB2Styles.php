<?php

namespace WilokeListingTools\Framework\Helpers;


class InheritCMB2Styles {

}