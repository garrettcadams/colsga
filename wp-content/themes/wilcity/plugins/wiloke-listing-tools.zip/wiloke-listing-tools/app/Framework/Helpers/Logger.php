<?php

namespace WilokeListingTools\Framework\Helpers;

class Logger
{
    public function writeAddListing($action = '')
    {

    }
}
