<?php

namespace WilokeListingTools\Framework\Payment;


interface SuspendInterface {
	public function suspend();
}