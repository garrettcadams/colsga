<thead>
<tr>
    <th class="invoices-id manage-column check-column">
        <input type="checkbox" name="wilcity_checkall" class="wiloke_checkall">
    </th>
	<th class="invoices-id manage-column check-column">#</th>
	<th class="invoices-package manage-column"><?php esc_html_e('Customer', 'wiloke'); ?></th>
	<th class="invoices-package manage-column"><?php esc_html_e('Plan Type', 'wiloke'); ?></th>
	<th class="invoices-package manage-column"><?php esc_html_e('Plan Name', 'wiloke'); ?></th>
	<th class="invoices-package manage-column"><?php esc_html_e('Status', 'wiloke'); ?></th>
	<th class="invoices-package manage-column"><?php esc_html_e('Gateway', 'wiloke'); ?></th>
	<th class="invoices-date manage-column"><?php esc_html_e('Date', 'wiloke'); ?></th>
</tr>
</thead>