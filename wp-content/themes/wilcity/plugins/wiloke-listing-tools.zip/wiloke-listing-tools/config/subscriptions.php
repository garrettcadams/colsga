<?php
return [
	'status' => array(
		''              => esc_html__('All', 'wiloke-listing-tools'),
		'suspended'     => esc_html__('Suspend', 'wiloke-listing-tools'),
		'cancelled'     => esc_html__('Cancel', 'wiloke-listing-tools'),
		'active'        => esc_html__('Active', 'wiloke-listing-tools')
	)
];