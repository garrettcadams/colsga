<?php
return [
	array(
		'wiloke_contributor',
		esc_html__('Wiloke Contributor', 'wiloke-listing-tools'),
		array(
			'read' => true,
			'upload_files' => false,
			'publish_listings' => false,
			'read_private_listings' => false,
			'delete_listing' => false
		)
	)
];