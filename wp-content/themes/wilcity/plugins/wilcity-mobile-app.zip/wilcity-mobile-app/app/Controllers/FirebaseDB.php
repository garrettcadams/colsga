<?php

namespace WILCITY_APP\Controllers;


class FirebaseDB {
	private function __connect(){

	}
}